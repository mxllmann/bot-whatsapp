import User from '../models/User.js';
import { handleCommandEventos } from './commands/eventos.js';

export async function handleMessage(msg, client) {
  if (!msg.body || typeof msg.body !== 'string' || msg.from.endsWith('@g.us')) return;

  const phone = msg.from;
  const text = msg.body.trim();
  const user = await User.findOne({ phone });

  if (text.startsWith('/eventos')) {
    const prompt = text.replace('/eventos', '').trim();
    return await handleCommandEventos(prompt, phone, client);
  }

  if (text.startsWith('/ajuda')) {
    return client.sendMessage(phone, '🤖 Comandos disponíveis:\n/eventos [data]');
  }
}
