import openai from '../../services/openaiServices.js';
import fetch from 'node-fetch';

export async function handleCommandEventos(prompt, phone, client) {
  const completion = await openai.chat.completions.create({
    model: 'gpt-4o-mini',
    messages: [
      {
        role: 'system',
        content: 'Converta o pedido do usuário em uma data no formato YYYY-MM-DD. Apenas a data como resposta.',
      },
      { role: 'user', content: prompt }
    ]
  });

  const isoDate = completion.choices[0].message.content.trim();
  if (!/\\d{4}-\\d{2}-\\d{2}/.test(isoDate)) {
    return client.sendMessage(phone, '❌ Não consegui entender a data.');
  }

  const response = await fetch(`${process.env.API_BASE_URL}/eventos?phone=${phone}&date=${isoDate}`);
  const eventos = await response.json();

  if (!eventos.length) {
    return client.sendMessage(phone, `📭 Nenhum evento encontrado para ${isoDate}.`);
  }

  const listagem = eventos.map(ev => {
    return `📌 ${ev.summary || 'Sem título'}\n🕒 ${ev.start?.dateTime || ev.start?.date}`;
  }).join('\n\n');

  const msgFinal = await openai.chat.completions.create({
    model: 'gpt-4o-mini',
    messages: [
      {
        role: 'system',
        content: 'Responda de forma simpática listando os compromissos do usuário para o dia indicado.',
      },
      { role: 'user', content: listagem }
    ]
  });

  return client.sendMessage(phone, msgFinal.choices[0].message.content.trim());
}
