import { oAuth2Client } from '../services/googleService.js';
import { google } from 'googleapis';
import User from '../models/User.js';

export const buscarEventosPorData = async (req, res) => {
  try {
    const { phone, date } = req.query;

    if (!phone || !date) return res.status(400).send('Parâmetros ausentes');

    const user = await User.findOne({ phone });
    if (!user || !user.refresh_token) return res.status(403).send('Usuário não autenticado');

    oAuth2Client.setCredentials({ refresh_token: user.refresh_token });

    const calendar = google.calendar({ version: 'v3', auth: oAuth2Client });
    const start = new Date(`${date}T00:00:00.000Z`);
    const end = new Date(`${date}T23:59:59.999Z`);

    const response = await calendar.events.list({
      calendarId: 'primary',
      timeMin: start.toISOString(),
      timeMax: end.toISOString(),
      singleEvents: true,
      orderBy: 'startTime',
    });

    res.json(response.data.items || []);
  } catch (err) {
    console.error(err);
    res.status(500).send('Erro ao buscar eventos');
  }
};
