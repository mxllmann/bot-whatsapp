import express from 'express';
import { buscarEventosPorData } from '../controllers/calendarController.js';

const router = express.Router();
router.get('/', buscarEventosPorData);

export default router;
